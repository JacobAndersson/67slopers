RIVET / BRAND STANDARDS
Open Rivet-brand-standards.pdf first. Use its contents or bookmarks to navigate.
Open web/index.html locally for the responsive homepage, workout and equipment examples.
The three SVGs in logos are the artwork masters. Text is outlined in those files.
Use motion/rivet-loading.svg for the approved loader; the startup file is a one-shot study.
The editable Penpot document is supplied alongside this kit. Install the two typefaces
in fonts if your design tool asks for them. Font licences are included.
The photographs and physical products in this delivery are visual studies. Print files
are review artwork. Confirm rights, final size, stock, bleed, cut paths and substrate
with the project owner and supplier before commercial production.

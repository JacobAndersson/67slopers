67slopers design study — 30 September 2026

Approved direction: Slab logo, Pulse / amber, all eight refined boards.
The previews now open with these selections.

Open storyboards.html, logos.html, or boards.html in a browser. Everything required
for the previews is bundled; no accounts, remote assets, or app data are used.

Three screen directions

Chalk: cobalt, chalk-white surfaces, compact hierarchy, a finite workout rail.
Traverse: pine, soft granite, open surfaces, a vertical workout list, left-aligned timer.
Pulse: amber with dark text, stronger display type, a finite rail, bold timer controls.
All retain Geist Mono. The palette switches compare proposals; they do not propose
a theme picker or multiple appearances in the shipped app.

Each direction has twelve screens: Home, Workout, Builder, Board setup, Choose grip,
Timer, Summary, Session, Calendar, Interrupted run, First launch, and Import.
Timer inspection also includes Get ready, Hang, Rest between reps, Rest between
sets, and Paused. Start runs a silent demonstration. Session totals are example
records rather than a replacement for the app's tested timer and persistence engine.

UX decisions

Start is the main Home action. Streaks and calendar follow it. Saved workout cards
are manually swiped or dragged, without infinite repetition or automatic motion.
Traverse offers a vertical-list alternative. The literal Obsidian GSAP marquee
component is not imported. Its visual rail treatment inspired the proposal.
Phase-label motion is brief and only responds to interval changes; digits do not
flip, and reduced-motion preferences suppress the animation.

Board setup is optional. The choice becomes the default for new workouts;
existing workouts keep their own board. Changes should confirm removal of any
grips that belong to the previous board. Board setup must not block one-tap Start.
The builder surfaces its selected board and opens a separate grip picker.
Grip selection uses the exact paired/center hold ids and labels from the app.
The timer reserves a stable area for the board and selected-grip guidance.

Logo alternatives

Eight concepts: Contour, Palm, Offset 67, Edge, Cadence, Sloper S, Crimp, and Slab.
Slab is the approved mark; the other concepts remain available for comparison.
Inspect all in color and
monochrome, launcher circle/rounded masks, and 48/32/24/16 px sizes.
icon-assets/ contains editable SVG symbols, three palettes for every concept,
1024 px app-icon PNGs, transparent adaptive foregrounds, monochrome layers,
small raster previews, and wordmark lockups. The Android symbol footprint is
56% of the full layer, within the 66/108 safe-zone proportion. Full icons have
unmasked backgrounds; platform corner masks are only used in the preview.
The embedded Geist Mono font is covered by LICENSE_FONT.

Board review

All eight supported boards have refined front-view artwork and selected-grip
variants. Wood and resin receive different surfaces. Cavities use restrained
depth shading, printed depth/angle labels are moved out of the board picture,
mounting holes follow layout.json, and a crisp selected rim preserves the cavity.
No board dimensions, hold ids, pair mappings, depths, or hold coordinates changed.
The SVG/PNG artwork is what the runner actually renders. The 3D GLB/OBJ meshes
were reviewed, but are not replaced by this study. Their heightmap construction
still approximates incuts, lower-tier relief, and sculpted resin silhouettes.
The refined drawings are visual guidance, not manufacturing geometry.
boards/ contains the candidate SVG and PNG artwork and selected examples.

Verification

The 36 screens plus 15 additional phase cases were checked in a real browser at
320, 736, and 1024 px. Audits check rendered bounds, nested buttons, and computed
text contrast inside the product screens. No unintended overflow or nested
buttons was found. The lowest measured text contrast was 7.31:1, meeting WCAG's
enhanced contrast threshold for normal text. This is not a complete WCAG AAA
conformance certification. Form controls use clear labels, visible focus, large
targets, and high-contrast borders/placeholders. Calendar cells also have larger
equivalent Previous day/Next day controls. Motion respects reduced-motion.

Browser checks also cover board setup into the builder, Start/Pause, the End
confirmation and summary, logo selection/palette changes, and board/grip selection.
All three fragment scripts pass node --check, contain no unresolved placeholders,
and remain below the inline visualization size limit.

The selected direction has now been applied to the production app: Pulse tokens,
Slab platform icons, task-first Home, eight refined board drawings and crisp amber
selection overlays. Optional local board setup defaults NEW workouts only, including
direct web links that hydrate storage after first render. Existing workouts retain
their own board choice.

The native builder retains editable prep/hang/rest lengths and labels, nested
repeats, duplication, deletion, moving in/out of repeats and drag reordering.
Step types are chosen before insertion, repeat groups have visible add controls,
step editing has a visible chevron, and narrow editors stack labels above values.
The storyboard builder uses the actual app tree helpers and interval expansion;
rest changes, added blocks and reordering affect its duration and demonstration.

The timer flips only phase words over 180 ms and respects reduced motion. Native
release-device animation feel remains to be checked. 3D meshes are unchanged.
Existing workspace timer, checkpoint, cue and board-visibility edits were preserved.

Implementation checks: typecheck, lint, format:check and all 134 tests pass.
A standalone web export also succeeds. Browser verification covers changing rest
3:00 to 2:30 (24:10 becomes 21:10), adding a nested repeat (27:10), saving and
reopening, inserting Rest directly, default board setup, and retaining a no-board
choice on an existing workout. Narrow controls were reviewed at 320 px.


Inspiration and references

https://www.obsidianui.dev/docs/flip-text
https://www.obsidianui.dev/docs/draggable-marquee
https://linear.app/now/how-we-redesigned-the-linear-ui
https://www.raycast.com/blog/a-fresh-look-and-feel
https://developer.android.com/develop/ui/compose/system/icon_design_adaptive
https://www.w3.org/WAI/WCAG22/Understanding/contrast-enhanced.html

Final implementation pass

Expanded timed-step editors use a neutral white card surface. Rest retains its
cool phase color in the timer, while selected grips use the amber rim.
The builder shows a compact selected-board preview with Change, collapsible
editable descriptions, complete step/repeat tools, and live bounded timing entry.
Typing updates the total immediately; Start and Save use that latest value even
when a length field remains focused.

Workout and import previews show total time, planned hanging time, sets and hangs
from the exact interval sequence. The grip sheet has larger, wrapping choices,
neutral unselected controls, and a pinned Use this grip action. Home's finite rail
supports native touch scrolling, web mouse dragging, and keyboard navigation.
Dragging does not open a card accidentally. The calendar has seven equal columns,
keeps dates visible, and shows only the selected day's sessions.

The timer has labeled, larger controls, a quiet next-step preview, the phase-word
flip, and the existing conditional board setup cues. Completion shows elapsed
wall-clock time (including pauses), full sets, actual hanging time and full hangs.
Session notes can be added on completion and edited later; both persist locally.
Direct-link Save/Close actions recover to the workout or Home.

Final verification: typecheck, lint, format:check, 134 tests, standalone web export,
and a local Android release APK build pass. Browser checks include a full three-
second board-enabled run (one full hang and one full set), neutral expanded editors,
focused-field timing saves, note persistence after reload, calendar day filtering,
mouse/keyboard rail navigation, QR sharing, import, and direct-link recovery.
Temporary verification sessions and workouts were removed through the app.
No connected Android device was available. Release-device motion feel, cue behavior,
keyboard/safe-area checks, and startup timing remain physical-device checks in
`docs/device-checklist.md`. The build is verified; device behavior is not certified.

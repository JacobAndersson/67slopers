import fs from 'node:fs';
import path from 'node:path';
import { Resvg } from '/home/jacob/workspace/hangboard/node_modules/@resvg/resvg-js/index.js';
const project='/home/jacob/workspace/hangboard';
const out='/tmp/67slopers-storyboards/boards';
fs.mkdirSync(out,{recursive:true});
const ids=['beastmaker-1000','beastmaker-2000','tension-grindstone-mk2','metolius-simulator-3d','metolius-project','metolius-wood-grips-compact','metolius-wood-grips-deluxe','fika-vetelangd'];
let source=fs.readFileSync(path.join(project,'scripts/gen-board-images.mjs'),'utf8');
source=source.slice(source.indexOf('const SCALE = 2;'),source.indexOf('const manifests = []'));
source=source.replace('const C = {','let C = {');
source=source.replace(/const png = \(svg\) =>[\s\S]*?function write\(/,'function write(');
const baseStart=source.indexOf('function baseHold('),baseEnd=source.indexOf('/** The bottom row',baseStart);
source=source.slice(0,baseStart)+`function baseHold(h,defs){
 if(h.type==='sloper'||h.type==='jug')return '<g data-hold="'+h.id+'">'+topHold(h).replace(/<text[\\s\\S]*?<\\/text>/g,'')+'</g>';
 const key='cavity-'+h.id,clip='cut-'+h.id;
 defs.push('<clipPath id="'+clip+'">'+holdShape(h,'')+'</clipPath>');
 const deep=h.type==='pocket'||h.type==='mono'||(h.depth_mm??20)>30;
 defs.push('<linearGradient id="'+key+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+C.recess+'"/><stop offset="0.55" stop-color="'+(deep?C.hold:C.holdShallow)+'"/><stop offset="1" stop-color="'+(deep?C.holdShallow:C.stripDark)+'"/></linearGradient>');
 const rim=holdShape(h,'fill="none" stroke="'+C.outline+'" stroke-width="0.55"');
 const lip=holdShape(h,'fill="none" stroke="'+C.lip+'" stroke-width="1.7" transform="translate(0 1.2)"');
 const floor='<rect x="'+h.x+'" y="'+(h.y+h.h*.77)+'" width="'+h.w+'" height="'+h.h*.23+'" fill="'+C.strip+'" opacity="'+(deep?.18:.55)+'" clip-path="url(#'+clip+')"/>';
 return '<g data-hold="'+h.id+'">'+lip+holdShape(h,'fill="url(#'+key+')"')+floor+rim+'</g>';
}
`+source.slice(baseEnd);
source=source.replace('stroke-width="1" mask="url(#board-silhouette)"','stroke-width="0.6" mask="url(#board-silhouette)"');
source=source.replace('fill="${C.body}" stroke="${C.outline}"','fill="url(#board-light)" stroke="${C.outline}"');
source=source.replace("const defs = [\n    `<mask", "const defs = [\n    `<linearGradient id=\"board-light\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"${C.lip}\"/><stop offset=\"0.18\" stop-color=\"${C.body}\"/><stop offset=\"0.8\" stop-color=\"${C.body}\"/><stop offset=\"1\" stop-color=\"${C.strip}\"/></linearGradient>`,\n    `<mask");
source=source.replace('const light = selected ? mix(C.primary, C.lip, 0.55) : C.lip;', 'const light = selected ? mix(C.primary, C.lip, 0.55) : mix(C.lip,C.body,0.2);');
source=source.replace('stroke-width="9"','stroke-width="5"').replace('stroke-width="7"','stroke-width="4"');
source=source.replace('${tier}\n${holds}', '${tier}\n${grain(layout,W,H)}\n${holds}\n${mounts(layout)}');
function grain(layout,W,H){if(layout.id==='metolius-project'||layout.id==='metolius-simulator-3d')return '';return `<g opacity="0.1" fill="none" stroke="#846B4A" stroke-width="0.5" clip-path="url(#material-clip)">${Array.from({length:12},(_,i)=>{let y=(i+1)*H/13;return `<path d="M0 ${y} C${W*.2} ${y-3} ${W*.3} ${y+4} ${W*.5} ${y} S${W*.8} ${y-3} ${W} ${y+1}"/>`;}).join('')}</g>`;}
function mounts(layout){return `<g>${(layout.screw_holes||[]).map(p=>`<circle cx="${p.x}" cy="${p.y}" r="2.5" fill="#F7F3E9" opacity="0.65"/><circle cx="${p.x}" cy="${p.y}" r="1.45" fill="#35342D"/><path d="M${p.x-1} ${p.y}h2" stroke="#CFCFC9" stroke-width="0.5"/>`).join('')}</g>`;}
const render=new Function('fs','path','grain','mounts',source+`return {baseSvg,holdShape,setPalette:p=>C=p,setCurrent:v=>CURRENT=v};`)(fs,path,grain,mounts);
const wood={body:'#DDCDB3',strip:'#C4B192',stripDark:'#917B5A',lip:'#F3E8D2',hold:'#63523D',holdShallow:'#8D7657',recess:'#3B3024',outline:'#978466',primary:'#173D9D',edge:'#102B74'};
const resin={body:'#D3DEE2',strip:'#B4C3CB',stripDark:'#879AA4',lip:'#EDF2F4',hold:'#4D626D',holdShallow:'#748A94',recess:'#2C424F',outline:'#8599A3',primary:'#173D9D',edge:'#102B74'};
const all=[];
for(const id of ids){const layout=JSON.parse(fs.readFileSync(path.join(project,'hangboard-models',id,'layout.json'),'utf8'));const W=layout.size_mm.width,H=layout.size_mm.height;render.setPalette(id==='metolius-project'||id==='metolius-simulator-3d'?resin:wood);let svg=render.baseSvg(layout,W,H);const silhouette=layout.outline?.length?`<path d="${layout.outline.map(([x,y],i)=>(i?'L':'M')+x+' '+y).join(' ')} Z"/>`:`<rect width="${W}" height="${H}" rx="${layout.corner_radius_mm||12}"/>`;svg=svg.replace('<defs>','<defs><clipPath id="material-clip">'+silhouette+'</clipPath>');const preferred=layout.holds.find(h=>h.type==='edge'&&h.depth_mm===20&&h.side==='left')||layout.holds.find(h=>h.type==='edge'&&h.side==='left')||layout.holds.find(h=>h.type==='edge');const grips=[];for(const h of layout.holds){if(h.side==='right')continue;const pair=h.pair?layout.holds.find(p=>p.id===h.pair):null;grips.push({id:h.id,label:h.label+(h.depth_mm!=null?' / '+h.depth_mm+' mm':''),ids:[h.id,...pair?[pair.id]:[]]});}
const highlights={};for(const h of layout.holds){highlights[h.id]=render.holdShape(h,'fill="none" stroke="#FFFFFF" stroke-width="5"')+render.holdShape(h,'fill="#173D9D" fill-opacity="0.12" stroke="#173D9D" stroke-width="2.5"');}
fs.writeFileSync(path.join(out,id+'.svg'),svg);fs.writeFileSync(path.join(out,id+'.png'),new Resvg(svg,{font:{loadSystemFonts:false,fontFiles:[]}}).render().asPng());
const selected=svg.replace('</svg>',(preferred?[preferred.id,preferred.pair].filter(Boolean).map(x=>highlights[x]).join(''):'')+'</svg>');fs.writeFileSync(path.join(out,id+'-selected.svg'),selected);fs.writeFileSync(path.join(out,id+'-selected.png'),new Resvg(selected).render().asPng());
all.push({id,name:layout.brand+' '+layout.model.replace(/ Series$/,''),width:W,height:H,grips,preferred:preferred?.id,svg,highlights,before:'data:image/png;base64,'+fs.readFileSync(path.join(project,'assets/boards',id,'base.png')).toString('base64')});}
fs.writeFileSync(path.join(out,'board-data.json'),JSON.stringify(all));
console.log('Refined '+all.length+' boards without changing any layout coordinates or hold ids.');

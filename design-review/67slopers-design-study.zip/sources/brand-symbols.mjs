export const symbols = [
  {
    id: 'contour', name: 'Contour', idea: 'Sloper / layered grip', recommended: true,
    shape: `<path d="M16 70C16 35 36 16 58 20c21 4 28 24 26 50H16Z" fill="currentColor"/><path d="M30 60c0-19 12-29 27-27M40 66c0-12 8-20 18-19" fill="none" stroke="var(--cut)" stroke-width="7" stroke-linecap="round"/>`
  },
  {
    id: 'palm', name: 'Palm', idea: 'Chalk / familiar hold', recommended: true,
    shape: `<path d="M26 21C40 10 65 14 77 30c16 19 11 46-6 56-19 11-46 2-54-16-7-17-5-36 9-49Z" fill="currentColor"/><g fill="var(--cut)"><rect x="27" y="28" width="8" height="18" rx="4" transform="rotate(-21 31 37)"/><rect x="41" y="22" width="8" height="20" rx="4" transform="rotate(-6 45 32)"/><rect x="55" y="25" width="8" height="20" rx="4" transform="rotate(15 59 35)"/><rect x="67" y="37" width="8" height="17" rx="4" transform="rotate(30 71 45)"/><path d="M30 58c10 13 27 16 39 7l-4-7c-10 6-22 2-29-6Z"/></g>`
  },
  {
    id: 'sixty-seven', name: 'Offset 67', idea: 'Name / compact signature', recommended: true,
    shape: `<path d="M45 19H31C19 19 13 27 13 40v24c0 12 8 19 19 19 12 0 20-8 20-20 0-12-8-20-20-20h-7v-3c0-6 3-9 8-9h12V19Zm-13 36c5 0 8 3 8 8s-3 8-8 8-7-3-7-8v-8h7Z" fill="currentColor"/><path d="M56 19h32v12L68 82H54l20-51H56Z" fill="currentColor"/>`
  },
  {
    id: 'edge', name: 'Edge', idea: 'Hangboard / strong geometry',
    shape: `<rect x="17" y="35" width="66" height="16" rx="5" fill="currentColor"/><path d="M24 48v27c0 7 5 11 11 11h8V72h-7V48Zm40 0v24h-7v14h8c6 0 11-4 11-11V48Z" fill="currentColor"/><rect x="24" y="14" width="12" height="14" rx="6" fill="currentColor"/><rect x="43" y="10" width="12" height="18" rx="6" fill="currentColor"/><rect x="62" y="14" width="12" height="14" rx="6" fill="currentColor"/>`
  },
  {
    id: 'cadence', name: 'Cadence', idea: 'Six reps / repeat rhythm',
    shape: `<g fill="none" stroke="currentColor" stroke-width="14" stroke-linecap="round"><path d="M31 22a34 34 0 0 1 22-5"/><path d="M69 23a34 34 0 0 1 14 17"/><path d="M83 57a34 34 0 0 1-11 19"/><path d="M55 83a34 34 0 0 1-22-5"/><path d="M20 65a34 34 0 0 1-4-22"/><path d="M20 30l2-3"/></g><path d="M39 58c1-15 7-21 15-17 5 3 7 9 7 17H39Z" fill="currentColor"/>`
  },
  {
    id: 'sloper-s', name: 'Sloper S', idea: 'Continuous grip / letterform',
    shape: `<path d="M80 25C65 12 42 12 27 23 14 33 12 49 23 59c10 8 25 8 37 10l-5 9c-11 1-23-3-33-10L14 80c14 12 38 17 56 8 15-8 20-26 10-38-9-10-23-11-36-13l5-9c8-1 16 2 24 7Z" fill="currentColor"/>`
  },
  {
    id: 'crimp', name: 'Crimp', idea: 'Two fingers / negative space',
    shape: `<path d="M14 24h72v17H14Z" fill="currentColor"/><path d="M24 37v25c0 11 9 19 20 19h5V66h-5c-3 0-5-2-5-5V37Zm37 0v24c0 3-2 5-5 5h-5v15h5c11 0 20-8 20-19V37Z" fill="currentColor"/><path d="M18 18h64" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>`
  },
  {
    id: 'slab', name: 'Slab', idea: 'Sloping hold / bold silhouette',
    shape: `<path d="M15 74 34 22c3-8 11-12 20-10l29 7-18 56c-2 8-10 12-18 10L15 74Z" fill="currentColor"/><path d="m32 62 12-30 23 6-12 31Z" fill="var(--cut)"/><path d="m32 62 23 7-3 9-24-6Z" fill="currentColor"/>`
  }
];
export const palettes={chalk:{name:'Chalk / cobalt',background:'#173D9D',foreground:'#FFFFFF',paper:'#F3F5F8',ink:'#15202B'},traverse:{name:'Traverse / pine',background:'#174A39',foreground:'#FFFFFF',paper:'#EDF2EE',ink:'#172A23'},pulse:{name:'Pulse / amber',background:'#F9C65D',foreground:'#20221F',paper:'#FAFAF7',ink:'#20221F'}};
